# Fronext-MD
`This is multie Device whatsapp bot Power by Avi`
<img src="https://i.ibb.co/8gMhyC7J/8488.jpg">
